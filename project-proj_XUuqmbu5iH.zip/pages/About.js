function About() {
    return (
        <div className="container mx-auto px-4 pt-20" data-name="about-page">
            <h2 className="text-3xl font-bold mb-6 gradient-text" data-name="about-title">About Us</h2>
            <div className="glass-effect p-6 rounded-lg" data-name="about-content">
                <p className="mb-4">
                    Welcome to our Weather Prediction service. We provide accurate and reliable weather forecasts
                    using advanced meteorological data and prediction models.
                </p>
                <p className="mb-4">
                    Our team of experienced meteorologists works around the clock to ensure you receive
                    the most up-to-date weather information for your location.
                </p>
                <div className="mt-8" data-name="features">
                    <h3 className="text-2xl font-semibold mb-4">Our Features</h3>
                    <ul className="list-disc list-inside">
                        <li>Real-time weather updates</li>
                        <li>7-day weather forecast</li>
                        <li>Detailed weather metrics</li>
                        <li>Interactive weather maps</li>
                        <li>Weather alerts and notifications</li>
                    </ul>
                </div>
            </div>
        </div>
    );
}

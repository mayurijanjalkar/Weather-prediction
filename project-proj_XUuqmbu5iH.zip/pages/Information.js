function Information() {
    return (
        <div className="container mx-auto px-4 pt-20" data-name="information-page">
            <h2 className="text-3xl font-bold mb-6 gradient-text" data-name="information-title">More Information</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6" data-name="info-grid">
                <div className="glass-effect p-6 rounded-lg" data-name="how-it-works">
                    <h3 className="text-2xl font-semibold mb-4">How It Works</h3>
                    <p className="mb-4">
                        Our weather predictions are based on sophisticated algorithms and data from multiple
                        weather stations worldwide. We analyze atmospheric conditions, pressure systems,
                        and historical weather patterns to provide accurate forecasts.
                    </p>
                </div>
                <div className="glass-effect p-6 rounded-lg" data-name="data-sources">
                    <h3 className="text-2xl font-semibold mb-4">Data Sources</h3>
                    <p className="mb-4">
                        We collect data from various reliable sources including:
                    </p>
                    <ul className="list-disc list-inside">
                        <li>Satellite imagery</li>
                        <li>Weather stations</li>
                        <li>Atmospheric sensors</li>
                        <li>Ocean buoys</li>
                    </ul>
                </div>
            </div>
        </div>
    );
}

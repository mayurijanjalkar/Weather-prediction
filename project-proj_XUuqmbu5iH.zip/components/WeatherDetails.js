function WeatherDetails({ data }) {
    return (
        <div className="glass-effect p-6 rounded-lg mt-6 fade-in" data-name="weather-details">
            <h3 className="text-2xl font-semibold mb-4 gradient-text">Weather Details</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="p-4 glass-effect rounded-lg" data-name="feels-like">
                    <div className="flex items-center mb-2">
                        <span className="text-2xl mr-2">🌡️</span>
                        <p className="text-gray-400">Feels Like</p>
                    </div>
                    <p className="text-2xl font-bold">{data.feelsLike}°C</p>
                </div>
                <div className="p-4 glass-effect rounded-lg" data-name="breeze">
                    <div className="flex items-center mb-2">
                        <span className="text-2xl mr-2">💨</span>
                        <p className="text-gray-400">Breeze</p>
                    </div>
                    <p className="text-2xl font-bold">{data.windSpeed} km/h</p>
                </div>
                <div className="p-4 glass-effect rounded-lg" data-name="humidity">
                    <div className="flex items-center mb-2">
                        <span className="text-2xl mr-2">💧</span>
                        <p className="text-gray-400">Humidity</p>
                    </div>
                    <p className="text-2xl font-bold">{data.humidity}%</p>
                </div>
                <div className="p-4 glass-effect rounded-lg" data-name="visibility">
                    <div className="flex items-center mb-2">
                        <span className="text-2xl mr-2">👁️</span>
                        <p className="text-gray-400">Visibility</p>
                    </div>
                    <p className="text-2xl font-bold">{data.visibility} km</p>
                </div>
            </div>
            <div className="mt-6 glass-effect p-4 rounded-lg" data-name="sun-info">
                <div className="flex justify-between items-center">
                    <div className="flex items-center">
                        <span className="text-2xl mr-2">🌅</span>
                        <div>
                            <p className="text-gray-400">Sunrise</p>
                            <p className="text-xl">{data.sunrise}</p>
                        </div>
                    </div>
                    <div className="flex items-center">
                        <span className="text-2xl mr-2">🌇</span>
                        <div>
                            <p className="text-gray-400">Sunset</p>
                            <p className="text-xl">{data.sunset}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

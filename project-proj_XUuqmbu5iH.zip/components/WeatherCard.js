function WeatherCard({ data }) {
    const getWeatherIcon = (condition) => {
        const icons = {
            'Clear': '☀️',
            'Partly Cloudy': '⛅',
            'Cloudy': '☁️',
            'Rain': '🌧️',
            'Snow': '🌨️',
            'Storm': '⛈️',
            'Windy': '💨'
        };
        return icons[condition] || '☀️';
    };

    return (
        <div className="weather-card card-shadow fade-in" data-name="weather-card">
            <div className="flex justify-between items-start">
                <div className="flex items-center gap-4" data-name="weather-info">
                    <div className="text-6xl weather-icon" data-name="weather-icon">
                        {getWeatherIcon(data.condition)}
                    </div>
                    <div>
                        <h3 className="text-xl font-semibold mb-2" data-name="weather-location">
                            {data.location}
                        </h3>
                        <p className="text-4xl font-bold mb-4 gradient-text" data-name="weather-temp">
                            {data.temperature}°C
                        </p>
                        <div className="flex gap-4" data-name="weather-details">
                            <p className="flex items-center">
                                <span className="mr-1">💧</span> {data.humidity}%
                            </p>
                            <p className="flex items-center">
                                <span className="mr-1">💨</span> {data.windSpeed} km/h
                            </p>
                        </div>
                    </div>
                </div>
                <div className="text-right" data-name="weather-condition">
                    <p className="text-lg">{data.condition}</p>
                    <p className="text-sm text-gray-400">{data.date}</p>
                </div>
            </div>
        </div>
    );
}

function DateTime() {
    const [currentTime, setCurrentTime] = React.useState(new Date());

    React.useEffect(() => {
        const timer = setInterval(() => {
            setCurrentTime(new Date());
        }, 1000);

        return () => clearInterval(timer);
    }, []);

    const formatDate = (date) => {
        const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        return date.toLocaleDateString('en-US', options);
    };

    const formatTime = (date) => {
        return date.toLocaleTimeString('en-US', { 
            hour: '2-digit', 
            minute: '2-digit', 
            second: '2-digit',
            hour12: true 
        });
    };

    return (
        <div className="text-center mb-6" data-name="date-time">
            <div className="text-4xl font-bold gradient-text" data-name="time">
                {formatTime(currentTime)}
            </div>
            <div className="text-lg text-gray-400" data-name="date">
                {formatDate(currentTime)}
            </div>
        </div>
    );
}

function WeatherCharts({ data }) {
    const temperatureChartRef = React.useRef(null);
    const humidityChartRef = React.useRef(null);
    const windChartRef = React.useRef(null);
    const predictionChartRef = React.useRef(null);

    React.useEffect(() => {
        if (temperatureChartRef.current) {
            const ctx = temperatureChartRef.current.getContext('2d');
            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: data.labels,
                    datasets: [{
                        label: 'Temperature (°C)',
                        data: data.temperatures,
                        backgroundColor: '#7C4DFF',
                        borderColor: '#9D7FFF',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: { color: 'rgba(255, 255, 255, 0.1)' },
                            ticks: { color: 'rgba(255, 255, 255, 0.7)' }
                        },
                        x: {
                            grid: { color: 'rgba(255, 255, 255, 0.1)' },
                            ticks: { color: 'rgba(255, 255, 255, 0.7)' }
                        }
                    },
                    plugins: {
                        legend: {
                            labels: { color: 'rgba(255, 255, 255, 0.7)' }
                        }
                    }
                }
            });
        }

        if (humidityChartRef.current) {
            const ctx = humidityChartRef.current.getContext('2d');
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: data.labels,
                    datasets: [{
                        label: 'Humidity (%)',
                        data: data.humidity,
                        borderColor: '#64B5F6',
                        tension: 0.4,
                        fill: false
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: { color: 'rgba(255, 255, 255, 0.1)' },
                            ticks: { color: 'rgba(255, 255, 255, 0.7)' }
                        },
                        x: {
                            grid: { color: 'rgba(255, 255, 255, 0.1)' },
                            ticks: { color: 'rgba(255, 255, 255, 0.7)' }
                        }
                    },
                    plugins: {
                        legend: {
                            labels: { color: 'rgba(255, 255, 255, 0.7)' }
                        }
                    }
                }
            });
        }

        if (windChartRef.current) {
            const ctx = windChartRef.current.getContext('2d');
            new Chart(ctx, {
                type: 'radar',
                data: {
                    labels: data.labels,
                    datasets: [{
                        label: 'Wind Speed (km/h)',
                        data: data.windSpeed,
                        backgroundColor: 'rgba(0, 230, 118, 0.2)',
                        borderColor: '#00E676',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        r: {
                            grid: { color: 'rgba(255, 255, 255, 0.1)' },
                            ticks: { color: 'rgba(255, 255, 255, 0.7)' }
                        }
                    },
                    plugins: {
                        legend: {
                            labels: { color: 'rgba(255, 255, 255, 0.7)' }
                        }
                    }
                }
            });
        }

        if (predictionChartRef.current) {
            const ctx = predictionChartRef.current.getContext('2d');
            new Chart(ctx, {
                type: 'scatter',
                data: {
                    datasets: [{
                        label: 'Weather Prediction',
                        data: data.predictions.map((p, i) => ({ x: i, y: p })),
                        backgroundColor: '#FF1744',
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: { color: 'rgba(255, 255, 255, 0.1)' },
                            ticks: { color: 'rgba(255, 255, 255, 0.7)' }
                        },
                        x: {
                            grid: { color: 'rgba(255, 255, 255, 0.1)' },
                            ticks: { color: 'rgba(255, 255, 255, 0.7)' }
                        }
                    },
                    plugins: {
                        legend: {
                            labels: { color: 'rgba(255, 255, 255, 0.7)' }
                        }
                    }
                }
            });
        }
    }, [data]);

    return (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6" data-name="weather-charts">
            <div className="chart-container" data-name="temperature-chart">
                <h3 className="text-xl font-semibold mb-4">Temperature Trend</h3>
                <canvas ref={temperatureChartRef}></canvas>
            </div>
            <div className="chart-container" data-name="humidity-chart">
                <h3 className="text-xl font-semibold mb-4">Humidity Trend</h3>
                <canvas ref={humidityChartRef}></canvas>
            </div>
            <div className="chart-container" data-name="wind-chart">
                <h3 className="text-xl font-semibold mb-4">Wind Pattern</h3>
                <canvas ref={windChartRef}></canvas>
            </div>
            <div className="chart-container" data-name="prediction-chart">
                <h3 className="text-xl font-semibold mb-4">Weather Prediction</h3>
                <canvas ref={predictionChartRef}></canvas>
            </div>
        </div>
    );
}

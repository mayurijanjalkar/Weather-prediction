function AirQuality({ data }) {
    const getAirQualityLevel = (aqi) => {
        if (aqi <= 50) return { level: 'Good', color: 'text-green-400', icon: '😊' };
        if (aqi <= 100) return { level: 'Moderate', color: 'text-yellow-400', icon: '😐' };
        if (aqi <= 150) return { level: 'Unhealthy for Sensitive Groups', color: 'text-orange-400', icon: '😷' };
        if (aqi <= 200) return { level: 'Unhealthy', color: 'text-red-400', icon: '🤢' };
        return { level: 'Very Unhealthy', color: 'text-purple-400', icon: '☠️' };
    };

    const quality = getAirQualityLevel(data.aqi);

    return (
        <div className="glass-effect p-6 rounded-lg mt-6 fade-in" data-name="air-quality">
            <h3 className="text-2xl font-semibold mb-4 gradient-text">Air Quality</h3>
            <div className="flex justify-between items-center mb-4">
                <div className="flex items-center">
                    <span className="text-4xl mr-3">{quality.icon}</span>
                    <div>
                        <p className="text-xl">Air Quality Index</p>
                        <p className={`text-lg ${quality.color}`}>{quality.level}</p>
                    </div>
                </div>
                <p className={`text-3xl font-bold ${quality.color}`}>{data.aqi}</p>
            </div>
            <div className="mt-4 grid grid-cols-2 md:grid-cols-3 gap-4">
                <div className="p-3 glass-effect rounded-lg">
                    <div className="flex items-center mb-1">
                        <span className="text-xl mr-2">💨</span>
                        <p className="text-gray-400">PM2.5</p>
                    </div>
                    <p className="text-xl">{data.pm25} µg/m³</p>
                </div>
                <div className="p-3 glass-effect rounded-lg">
                    <div className="flex items-center mb-1">
                        <span className="text-xl mr-2">🌫️</span>
                        <p className="text-gray-400">PM10</p>
                    </div>
                    <p className="text-xl">{data.pm10} µg/m³</p>
                </div>
                <div className="p-3 glass-effect rounded-lg">
                    <div className="flex items-center mb-1">
                        <span className="text-xl mr-2">🌬️</span>
                        <p className="text-gray-400">O₃</p>
                    </div>
                    <p className="text-xl">{data.o3} ppb</p>
                </div>
            </div>
        </div>
    );
}

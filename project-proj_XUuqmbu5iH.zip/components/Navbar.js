function Navbar({ setCurrentPage }) {
    return (
        <nav className="navbar fixed top-0 w-full z-50 px-4 py-3" data-name="navbar">
            <div className="container mx-auto flex justify-between items-center">
                <h1 className="text-2xl font-bold gradient-text" data-name="nav-title">Weather Prediction</h1>
                <div className="flex gap-4" data-name="nav-links">
                    <button 
                        onClick={() => setCurrentPage('dashboard')}
                        className="text-white hover:text-primary-light transition-colors"
                        data-name="nav-dashboard">
                        Dashboard
                    </button>
                    <button 
                        onClick={() => setCurrentPage('about')}
                        className="text-white hover:text-primary-light transition-colors"
                        data-name="nav-about">
                        About Us
                    </button>
                    <button 
                        onClick={() => setCurrentPage('information')}
                        className="text-white hover:text-primary-light transition-colors"
                        data-name="nav-information">
                        More Information
                    </button>
                </div>
            </div>
        </nav>
    );
}

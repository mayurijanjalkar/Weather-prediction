function LifestyleTips({ weatherData, airQuality }) {
    const getTips = () => {
        const tips = [
            {
                type: 'indoor',
                icon: '🏠',
                suitable: weatherData.temperature > 30 || weatherData.rain > 0,
                message: 'Indoor activities'
            },
            {
                type: 'carwash',
                icon: '🚗',
                suitable: weatherData.rain === 0 && airQuality.aqi < 100,
                message: 'Car wash conditions'
            },
            {
                type: 'pollen',
                icon: '🌸',
                suitable: weatherData.pollenCount < 50,
                message: weatherData.pollenCount < 50 ? 'Low pollen count' : 'High pollen count'
            },
            {
                type: 'traffic',
                icon: '🚦',
                suitable: weatherData.visibility > 5,
                message: weatherData.visibility > 5 ? 'Good traffic conditions' : 'Poor visibility'
            },
            {
                type: 'mosquitoes',
                icon: '🦟',
                suitable: !(weatherData.humidity > 60 && weatherData.temperature > 20),
                message: 'Mosquito activity'
            },
            {
                type: 'trip',
                icon: '🏃',
                suitable: weatherData.rain === 0 && airQuality.aqi < 100 && weatherData.visibility > 8,
                message: 'Outdoor activities'
            }
        ];
        return tips;
    };

    return (
        <div className="glass-effect p-6 rounded-lg mt-6 fade-in" data-name="lifestyle-tips">
            <h3 className="text-2xl font-semibold mb-4 gradient-text">Lifestyle Tips</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {getTips().map((tip, index) => (
                    <div 
                        key={index} 
                        className="p-4 glass-effect rounded-lg flex items-center"
                        data-name={`tip-${tip.type}`}
                    >
                        <span className="text-2xl mr-3">{tip.icon}</span>
                        <div>
                            <p className={`font-semibold ${tip.suitable ? 'text-green-400' : 'text-red-400'}`}>
                                {tip.suitable ? 'Suitable' : 'Not Suitable'}
                            </p>
                            <p className="text-gray-400">{tip.message}</p>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}

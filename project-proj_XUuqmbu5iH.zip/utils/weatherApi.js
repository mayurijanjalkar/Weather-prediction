async function fetchWeatherData(location) {
    try {
        // Simulated API call
        return {
            location: location,
            temperature: Math.floor(Math.random() * 30) + 10,
            feelsLike: Math.floor(Math.random() * 30) + 8,
            humidity: Math.floor(Math.random() * 50) + 30,
            windSpeed: Math.floor(Math.random() * 20) + 5,
            visibility: Math.floor(Math.random() * 10) + 5,
            condition: "Partly Cloudy",
            date: new Date().toLocaleDateString(),
            sunrise: "06:30 AM",
            sunset: "06:45 PM",
            rain: Math.random() > 0.7 ? Math.random() * 10 : 0,
            pollenCount: Math.floor(Math.random() * 100),
        };
    } catch (error) {
        reportError(error);
        throw new Error('Failed to fetch weather data');
    }
}

async function fetchAirQualityData() {
    try {
        return {
            aqi: Math.floor(Math.random() * 200) + 1,
            pm25: Math.floor(Math.random() * 100),
            pm10: Math.floor(Math.random() * 150),
            o3: Math.floor(Math.random() * 50),
        };
    } catch (error) {
        reportError(error);
        throw new Error('Failed to fetch air quality data');
    }
}

async function getCurrentLocation() {
    try {
        return new Promise((resolve, reject) => {
            if (!navigator.geolocation) {
                reject(new Error('Geolocation is not supported by your browser'));
                return;
            }

            navigator.geolocation.getCurrentPosition(
                (position) => {
                    resolve({
                        latitude: position.coords.latitude,
                        longitude: position.coords.longitude
                    });
                },
                (error) => {
                    reject(new Error(`Failed to get location: ${error.message}`));
                }
            );
        });
    } catch (error) {
        reportError(error);
        throw new Error('Failed to get current location');
    }
}

async function fetchForecastData() {
    try {
        const labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
        return {
            labels,
            temperatures: labels.map(() => Math.floor(Math.random() * 20) + 10),
            humidity: labels.map(() => Math.floor(Math.random() * 50) + 30),
            windSpeed: labels.map(() => Math.floor(Math.random() * 20) + 5),
            predictions: labels.map(() => Math.floor(Math.random() * 30) + 10),
            rainfall: labels.map(() => Math.random() > 0.7 ? Math.floor(Math.random() * 10) : 0),
            pressure: labels.map(() => Math.floor(Math.random() * 50) + 980),
            uvIndex: labels.map(() => Math.floor(Math.random() * 11)),
            airQuality: labels.map(() => Math.floor(Math.random() * 200) + 1)
        };
    } catch (error) {
        reportError(error);
        throw new Error('Failed to fetch forecast data');
    }
}

async function getPredictionAccuracy() {
    try {
        return Math.floor(Math.random() * 20) + 80; // Returns accuracy between 80-100%
    } catch (error) {
        reportError(error);
        throw new Error('Failed to calculate prediction accuracy');
    }
}

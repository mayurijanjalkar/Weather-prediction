function App() {
    const [currentPage, setCurrentPage] = React.useState('dashboard');

    const renderPage = () => {
        switch(currentPage) {
            case 'about':
                return <About />;
            case 'information':
                return <Information />;
            default:
                return <Dashboard />;
        }
    };

    return (
        <div className="min-h-screen bg-background-default" data-name="app">
            <Navbar setCurrentPage={setCurrentPage} />
            {renderPage()}
        </div>
    );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);

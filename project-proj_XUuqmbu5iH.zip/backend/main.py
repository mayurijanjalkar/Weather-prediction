from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
import models, schemas, crud
from database import engine, get_db
from typing import List
import weather_service

models.Base.metadata.create_all(bind=engine)

app = FastAPI()

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/users/", response_model=schemas.User)
def create_user(user: schemas.UserCreate, db: Session = Depends(get_db)):
    db_user = crud.get_user_by_email(db, email=user.email)
    if db_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    return crud.create_user(db=db, user=user)

@app.get("/weather/{location_id}", response_model=schemas.WeatherData)
async def get_weather(location_id: int, db: Session = Depends(get_db)):
    location = crud.get_location(db, location_id)
    if not location:
        raise HTTPException(status_code=404, detail="Location not found")
    
    weather_data = await weather_service.fetch_weather_data(location.latitude, location.longitude)
    return crud.create_weather_data(db=db, weather_data=weather_data, location_id=location_id)

@app.get("/air-quality/{location_id}", response_model=schemas.AirQuality)
async def get_air_quality(location_id: int, db: Session = Depends(get_db)):
    location = crud.get_location(db, location_id)
    if not location:
        raise HTTPException(status_code=404, detail="Location not found")
    
    air_quality = await weather_service.fetch_air_quality(location.latitude, location.longitude)
    return crud.create_air_quality(db=db, air_quality=air_quality, location_id=location_id)

@app.post("/locations/", response_model=schemas.Location)
def create_location(location: schemas.LocationCreate, user_id: int, db: Session = Depends(get_db)):
    return crud.create_location(db=db, location=location, user_id=user_id)

@app.get("/locations/{user_id}", response_model=List[schemas.Location])
def get_user_locations(user_id: int, db: Session = Depends(get_db)):
    return crud.get_user_locations(db=db, user_id=user_id)

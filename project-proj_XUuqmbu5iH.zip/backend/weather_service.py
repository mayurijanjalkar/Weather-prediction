import aiohttp
from dotenv import load_dotenv
import os

load_dotenv()

OPENWEATHER_API_KEY = os.getenv("OPENWEATHER_API_KEY")

async def fetch_weather_data(lat: float, lon: float):
    async with aiohttp.ClientSession() as session:
        url = f"http://api.openweathermap.org/data/2.5/weather?lat={lat}&lon={lon}&appid={OPENWEATHER_API_KEY}&units=metric"
        async with session.get(url) as response:
            data = await response.json()
            return {
                "temperature": data["main"]["temp"],
                "humidity": data["main"]["humidity"],
                "wind_speed": data["wind"]["speed"],
                "condition": data["weather"][0]["main"]
            }

async def fetch_air_quality(lat: float, lon: float):
    async with aiohttp.ClientSession() as session:
        url = f"http://api.openweathermap.org/data/2.5/air_pollution?lat={lat}&lon={lon}&appid={OPENWEATHER_API_KEY}"
        async with session.get(url) as response:
            data = await response.json()
            return {
                "aqi": data["list"][0]["main"]["aqi"],
                "pm25": data["list"][0]["components"]["pm2_5"],
                "pm10": data["list"][0]["components"]["pm10"],
                "o3": data["list"][0]["components"]["o3"]
            }

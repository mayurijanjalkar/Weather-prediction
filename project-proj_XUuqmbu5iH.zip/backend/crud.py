from sqlalchemy.orm import Session
import models, schemas
from passlib.context import CryptContext

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def get_user(db: Session, user_id: int):
    return db.query(models.User).filter(models.User.id == user_id).first()

def get_user_by_email(db: Session, email: str):
    return db.query(models.User).filter(models.User.email == email).first()

def create_user(db: Session, user: schemas.UserCreate):
    hashed_password = pwd_context.hash(user.password)
    db_user = models.User(email=user.email, hashed_password=hashed_password)
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

def create_location(db: Session, location: schemas.LocationCreate, user_id: int):
    db_location = models.Location(**location.dict(), user_id=user_id)
    db.add(db_location)
    db.commit()
    db.refresh(db_location)
    return db_location

def get_location(db: Session, location_id: int):
    return db.query(models.Location).filter(models.Location.id == location_id).first()

def get_user_locations(db: Session, user_id: int):
    return db.query(models.Location).filter(models.Location.user_id == user_id).all()

def create_weather_data(db: Session, weather_data: schemas.WeatherDataBase, location_id: int):
    db_weather = models.WeatherData(**weather_data.dict(), location_id=location_id)
    db.add(db_weather)
    db.commit()
    db.refresh(db_weather)
    return db_weather

def create_air_quality(db: Session, air_quality: schemas.AirQualityBase, location_id: int):
    db_air_quality = models.AirQuality(**air_quality.dict(), location_id=location_id)
    db.add(db_air_quality)
    db.commit()
    db.refresh(db_air_quality)
    return db_air_quality

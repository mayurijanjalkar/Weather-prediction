from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime

class UserBase(BaseModel):
    email: str

class UserCreate(UserBase):
    password: str

class User(UserBase):
    id: int
    class Config:
        orm_mode = True

class LocationBase(BaseModel):
    name: str
    latitude: float
    longitude: float

class LocationCreate(LocationBase):
    pass

class Location(LocationBase):
    id: int
    user_id: int
    class Config:
        orm_mode = True

class WeatherDataBase(BaseModel):
    temperature: float
    humidity: float
    wind_speed: float
    condition: str

class WeatherData(WeatherDataBase):
    id: int
    timestamp: datetime
    location_id: int
    class Config:
        orm_mode = True

class AirQualityBase(BaseModel):
    aqi: int
    pm25: float
    pm10: float
    o3: float

class AirQuality(AirQualityBase):
    id: int
    timestamp: datetime
    location_id: int
    class Config:
        orm_mode = True
